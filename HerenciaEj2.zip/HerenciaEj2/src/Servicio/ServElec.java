/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servicio;


import Entidad.Electrodomestico;
import Enum.Color;
import java.util.Scanner;

/**
 *
 * @author Carlitos
 */
public class ServElec{
    private Scanner leer;
    private float precioLetra;
    private float precioFinal;
    private String letra;
    private float precioPeso;
    Electrodomestico elec;
    
    

    public ServElec() {
        this.elec = new Electrodomestico();
        this.leer = new Scanner(System.in).useDelimiter("\n");
        this.precioLetra = 0;
        this.letra = "";
        this.precioFinal = 0;
        this.precioPeso = 0;
    }
    
    public void comprobarConsumoElectrico(){
        
        
        if (letra.equalsIgnoreCase("a")) {
                precioLetra = this.elec.getPrecio() + 1000;
            } 
        if (letra.equalsIgnoreCase("b")) {
                precioLetra = this.elec.getPrecio() + 800;
            } 
        if (letra.equalsIgnoreCase("c")) {
                precioLetra = this.elec.getPrecio() + 600;
            } 
        if (letra.equalsIgnoreCase("d")) {
                precioLetra = this.elec.getPrecio() + 500;
            } 
        if (letra.equalsIgnoreCase("e")) {
                precioLetra = this.elec.getPrecio() + 300;
            } 
        if (letra.equalsIgnoreCase("f")) {
                precioLetra = this.elec.getPrecio() + 100;
        }    
}
    public void ComprobarColor(){
        
        String colo = leer.next();
        for (Color c : Color.values()) {

            if(c.name().equalsIgnoreCase(colo)){
                this.elec.setColor(c);
                break;
            }
        }
    }
    
    public void precioFinal(){
        precioFinal =  this.precioLetra + this.precioPeso;
        this.elec.setPrecio(precioFinal);
    }
    
    public void crearElectrodomestico(){
        
//        System.out.println("Ingresa el precio del electrodomestico: ");
//        this.elec.setPrecio(leer.nextFloat());
        System.out.println("Ingresa la letra del consumo electrico: A,B,C,D,F");
        letra = leer.next().toLowerCase();
        if(letra.equalsIgnoreCase("a")|| 
           letra.equalsIgnoreCase("b")|| 
           letra.equalsIgnoreCase("c")|| 
           letra.equalsIgnoreCase("d")|| 
           letra.equalsIgnoreCase("e")|| 
           letra.equalsIgnoreCase("f")) {
            this.elec.setConsumoElectrico(letra);
            
        } else {
            letra = "f";
             this.elec.setConsumoElectrico(letra);
        }
        comprobarConsumoElectrico();
        System.out.println("Ingresa el color: ");
        ComprobarColor();
        System.out.println("Peso?: ");
        this.elec.setPeso(leer.nextFloat());
        if(this.elec.getPeso() >=1 && this.elec.getPeso() <=19){
            precioPeso +=  100;
        }else if(this.elec.getPeso() >=20 && this.elec.getPeso() <=49){
            precioPeso += 500;
        }else if(this.elec.getPeso() >=50 && this.elec.getPeso() <=79){
            precioPeso += 800;
        }else if(this.elec.getPeso() >=81){
            precioPeso += 1000;
        }
     
        precioFinal();
        
        System.out.println("Calculado Precio: " + this.elec.getPrecio());
        System.out.println("Tipo de Consumo: " + this.elec.getConsumoElectrico());
        System.out.println("Color: " + this.elec.getColor());
        System.out.println("Peso: " + this.elec.getPeso() + " Kg");
    }

    
 
}
    

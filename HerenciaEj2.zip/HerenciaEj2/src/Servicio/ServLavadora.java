/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servicio;

import Entidad.Electrodomestico;
import Entidad.Lavadora;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Carlitos
 */
public class ServLavadora {
    private Scanner leer;
    private ArrayList<Lavadora>listaLavadoras;
    private ArrayList<Electrodomestico>listaElec;

    public ServLavadora() {
        this.leer = new Scanner(System.in).useDelimiter("\n");
        this.listaLavadoras = new ArrayList();
        this.listaElec = new ArrayList();
    }
    
    public Lavadora crearLavadora(){
        System.out.println("----------Carga de Lavadora----------");
        Lavadora lav = new Lavadora();
        ServElec se = new ServElec();
        System.out.print("Tipo de carga: ");
        lav.setCarga(leer.next());
        se.crearElectrodomestico();
        listaLavadoras.add(lav);
        listaElec.add(lav);
        
        return lav;
    }
    
    public void mostrarLavadora(){
        
        for (Lavadora lLav : listaLavadoras) {
            System.out.println(lLav);
            
        }
    }
}

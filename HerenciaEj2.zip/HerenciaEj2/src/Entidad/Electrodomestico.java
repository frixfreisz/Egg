/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidad;

import Enum.Color;

/**
 *
 * @author Carlitos
 */
public class Electrodomestico {
    protected float precio;
    protected Color color;
    protected String consumoElectrico;
    protected float peso;

    public Electrodomestico() {
        this.consumoElectrico = consumoElectrico;
        this.color = Color.BLANCO;
        this.precio = 1000;
        
    }

    public Electrodomestico(float peso, float precio, String consumoElectrico) {
        this.precio = 1000;
        this.color = Color.BLANCO;
        this.consumoElectrico = consumoElectrico;
        this.peso = peso;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }

    public String getConsumoElectrico() {
        return consumoElectrico;
    }

    public void setConsumoElectrico(String consumoElectrico) {
        this.consumoElectrico = consumoElectrico;
    }

    public float getPeso() {
        return peso;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }

    @Override
    public String toString() {
        return "Electrodomesticos" + "precio=" + precio + ", color=" + color + ", consumoElectrico=" + consumoElectrico + ", peso=" + peso + '}';
    }
    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidad;

import Servicio.ServElec;
import java.util.Scanner;

/**
 *
 * @author Carlitos
 */
public class Lavadora extends Electrodomestico {
    Scanner leer = new Scanner(System.in).useDelimiter("\n");
    private String carga;
    

    public Lavadora() {
        this.carga = carga;
    }

    public Lavadora(String carga, float peso, float precio, String consumoElectrico) {
        super(peso, precio, consumoElectrico);
        this.carga = carga;
    }

    public String getCarga() {
        return carga;
    }

    public void setCarga(String carga) {
        this.carga = carga;
    }

    @Override
    public String toString() {
        return "Carga: " + carga;
    }


public void crearLavadora(){
    ServElec serv = new ServElec();
    serv.crearElectrodomestico();
    System.out.println("Tipo de carga?:");
    this.carga = leer.next();
    
}    
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herenciaej2;

import Entidad.Electrodomestico;
import Servicio.ServElec;
import Servicio.ServLavadora;

/**
 *
 * @author Carlitos
 */
public class HerenciaEj2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       ServLavadora serv = new ServLavadora();
       serv.crearLavadora();
       serv.mostrarLavadora();
        
                
    }
    
}
